'''
speciesType	tissueType	UberonOntologyID	cancerType	cellType	cellName	CellOntologyID	cellMarker	geneSymbol	geneID	proteinName	proteinID	markerResource	PMID	Company
Mouse	Bone marrow	UBERON_0002371	Normal	Normal cell	Blastema cell	CL_0000354	CD31, Sca-1, Vim	Pecam1, Ly6a, Vim	18613, 110454, 22352	PECA1, LY6A, VIME	Q08481, P05533, P20152	Experiment	29105393	NA

Human_cell_markers.txt
Mouse_cell_markers.txt
'''


import os

cell_dic = {}
file_directory = 'cell_types'
file_directory_human = 'cell_types/human'
file_directory_mouse = 'cell_types/mouse'

def make_directories(f_directory):
	if not os.path.exists(f_directory):
		 os.makedirs(f_directory)

make_directories(file_directory)
make_directories(file_directory_human)
make_directories(file_directory_mouse)

def make_marker_files(filename, gmt_file):
	with open(filename, 'r') as input_file:
		input_file.readline()

		for line in input_file.readlines():
			sLine = line.split('\t')
			tissue = sLine[1].replace(' ', '_')
			cell_state = sLine[3].replace(' ', '_')
			cell_type = sLine[5].replace(' ', '_')
			cell_type = cell_type + '_' + tissue

			if 'Normal' not in line: #adds cancer type to cell type
				cell_type = cell_type + '_' + cell_state

			cell_type = cell_type.replace('(', '').replace(')', '').replace('+', '_plus').replace('/', '_')

			official_genes = sLine[8].replace(' ', '').replace('[', '').replace(']', '').replace('NA,', '').split(',')
			string_genes = sLine[8].replace('NA,', '')  #.replace(' ', '').replace('[', '').replace(']', '').split(',')
			#print(string_genes)
			#print('')

			if cell_type not in cell_dic:
				cell_dic[cell_type] = []
			for g in official_genes:
				if g not in cell_dic[cell_type] and g != 'NA':
					cell_dic[cell_type].append(g)

	with open(gmt_file, 'w') as o_file:
		for cell in cell_dic:
			out_line = cell + '\thttp://bio-bigdata.hrbmu.edu.cn/CellMarker/'
			list(set(cell_dic[cell]))
			organism = 'human'
			filename_organism = file_directory_human + '/' + cell + '.txt'
			if 'Mouse' in filename:
				organism = 'mouse'
				filename_organism = file_directory_mouse + '/' + cell + '.txt'

			if len(cell_dic[cell]) > 0:
				#print(filename_organism)

				with open(filename_organism, 'w') as output_file:
					for gene in cell_dic[cell]:
						if organism == 'human':
							gene = gene.upper()
						if organism == 'mouse':
							gene = gene.lower().capitalize()
						output_file.write(gene + '\n')
						out_line = out_line + '\t' + gene
					out_line = out_line + '\n'
			o_file.write(out_line)
				
make_marker_files('Mouse_cell_markers.txt', 'CellMarker_mouse.gmt')
make_marker_files('Human_cell_markers.txt', 'CellMarker_human.gmt')
