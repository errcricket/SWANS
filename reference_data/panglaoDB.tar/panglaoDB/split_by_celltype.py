'''
Author:  E. Reichenberger
Date: ...2021-ish

species	official gene symbol	cell type	nicknames	ubiquitousness index	product description	gene type	canonical marker	germ layer	organ	sensitivity_human	sensitivity_mouse	specificity_human	specificity_mouse
Mm Hs	CTRB1	Acinar cells	CTRB	0.017	chymotrypsinogen B1	protein-coding gene	1	Endoderm	Pancreas	1.0	0.957143	0.000628931	0.0159201

gmt
BIOCARTA_GRANULOCYTES_PATHWAY http://www.gsea-msigdb.org/gsea/msigdb/cards/BIOCARTA_GRANULOCYTES_PATHWAY CXCL8 IFNG  IL1A  CSF3  SELP  ITGAM ITGAL TNF   ITGB2 PECAM1   ICAM2 C5 SELPLG   ICAM1 SELL
BIOCARTA_LYM_PATHWAY http://www.gsea-msigdb.org/gsea/msigdb/cards/BIOCARTA_LYM_PATHWAY CXCL8 IL1A  MADCAM1  VCAM1 ITGAL CD34  ITGB2 PECAM1   ICAM2 ITGA4 GLYCAM1  ICAM1 ITGB1 SELLBIOCARTA_BLYMPHOCYTE_PATHWAY  http://www.gsea-msigdb.org/gsea/msigdb/cards/BIOCARTA_BLYMPHOCYTE_PATHWAY  CD80  ITGAL CR1   ITGB2 CR2   CD40  HLA-DRA  HLA-DRB5 ICAM1 FCGR2B   PTPR
'''
import os

cell_dic_human = {}
cell_dic_mouse = {}
file_directory = 'cell_types'
file_directory_human = 'cell_types/human'
file_directory_mouse = 'cell_types/mouse'

sensitivity_threshold = 0.6

def make_directories(f_directory):
	if not os.path.exists(f_directory):
		 os.makedirs(f_directory)

make_directories(file_directory)
make_directories(file_directory_human)
make_directories(file_directory_mouse)

with open('PanglaoDB_markers_27_Mar_2020.tsv', 'r') as input_file:
	input_file.readline()

	for line in input_file.readlines():
		sLine = line.split('\t')
		organism = sLine[0]
		official_gene = sLine[1]
		cell_type = sLine[2].replace(' ', '_').replace('/', '_')
		organ = sLine[9]
		cell_type = cell_type + '_' + organ
		cell_type = cell_type.replace(' ', '_').replace(')', '').replace('(', '').replace('-', '_')
		sensitivity_human = sLine[10]
		sensitivity_mouse = sLine[11]

		if ('Hs' in organism) and (sensitivity_human != 'NA') and (float(sensitivity_human) > sensitivity_threshold):
			if cell_type not in cell_dic_human:
				cell_dic_human[cell_type] = []
			cell_dic_human[cell_type].append(official_gene)

		if ('Hs' in organism) and (sensitivity_mouse != 'NA') and (float(sensitivity_mouse) > sensitivity_threshold):
			if cell_type not in cell_dic_mouse:
				cell_dic_mouse[cell_type] = []
			cell_dic_mouse[cell_type].append(official_gene.lower().capitalize())

with open('panglaoDB_human.gmt', 'w') as o_file:
	for cell in cell_dic_human:
		filename_human = file_directory_human + '/' + cell + '.txt'
		filename_human = filename_human.replace(' ', '_').replace(')', '').replace('(', '')
		with open(filename_human, 'w') as output_file:
			out_line = cell + '\thttps://panglaodb.se/\t' 
			for gene in cell_dic_human[cell]:
				out_line = out_line + gene + ' '
				output_file.write(gene + '\n')
			out_line = out_line.lstrip().rstrip()
			out_line = out_line + '\n'
		o_file.write(out_line)

with open('panglaoDB_mouse.gmt', 'w') as o_file:
	for cell in cell_dic_mouse:
		filename_mouse = file_directory_mouse + '/' + cell + '.txt'
		filename_mouse = filename_mouse.replace(' ', '_').replace(')', '').replace('(', '')
		with open(filename_mouse, 'w') as output_file:
			out_line = cell + '\thttps://panglaodb.se/\t' 
			for gene in cell_dic_mouse[cell]:
				out_line = out_line + gene + ' '
				#out_line = out_line + '\t' + gene
				output_file.write(gene + '\n')
			out_line = out_line.lstrip().rstrip()
			out_line = out_line + '\n'
		o_file.write(out_line)

'''
for cell in cell_dic:
	filename_human = file_directory_human + '/' + cell + '.txt'
	filename_mouse = file_directory_mouse + '/' + cell + '.txt'
	with open(filename_human, 'w') as output_file:
		for gene in cell_dic[cell]:
			output_file.write(gene + '\n')
	with open(filename_mouse, 'w') as output_file_m:
		for gene in cell_dic[cell]:
			output_file_m.write(gene.lower().capitalize() + '\n')
'''
